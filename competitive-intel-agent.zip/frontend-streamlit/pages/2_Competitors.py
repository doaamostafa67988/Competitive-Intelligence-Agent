"""
Manage the list of tracked competitors and their source URLs (pricing page,
careers page). These feed the Research Agent on the next pipeline run.
"""
import streamlit as st
import api_client as api

st.set_page_config(page_title="Competitors", page_icon="🏢", layout="wide")
st.title("🏢 Tracked Competitors")

with st.form("add_competitor"):
    st.subheader("Add / update a competitor")
    name = st.text_input("Competitor name*")
    pricing_url = st.text_input("Pricing page URL")
    careers_url = st.text_input("Careers page URL")
    submitted = st.form_submit_button("Save")
    if submitted:
        if not name:
            st.error("Competitor name is required.")
        else:
            try:
                api.upsert_competitor(name, pricing_url or None, careers_url or None)
                st.success(f"Saved {name}.")
                st.rerun()
            except Exception as e:
                st.error(f"Failed to save: {e}")

st.divider()
st.subheader("Currently tracked")
try:
    competitors = api.list_competitors()
    if competitors:
        for c in competitors:
            col_name, col_pricing, col_careers, col_remove = st.columns([2, 3, 3, 1])
            col_name.write(f"**{c.get('name')}**")
            col_pricing.write(c.get("pricing_url") or "—")
            col_careers.write(c.get("careers_url") or "—")
            if col_remove.button("Remove", key=f"remove_{c.get('name')}"):
                try:
                    api.remove_competitor(c["name"])
                    st.rerun()
                except Exception as e:
                    st.error(f"Failed to remove: {e}")
    else:
        st.info("No competitors added yet.")
except Exception as e:
    st.warning(f"Could not reach backend: {e}")
